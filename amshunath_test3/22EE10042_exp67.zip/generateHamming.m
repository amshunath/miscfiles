function [X]=generateHammming(N)
    X=hamming(N);
end